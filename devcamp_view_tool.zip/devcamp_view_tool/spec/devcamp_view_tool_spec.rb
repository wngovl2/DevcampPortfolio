require "spec_helper"

describe DevcampViewTool do
  it "has a version number" do
    expect(DevcampViewTool::VERSION).not_to be nil
  end

  it "does something useful" do
    expect(false).to eq(true)
  end
end